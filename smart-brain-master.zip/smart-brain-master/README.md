# SmartBrain - Final
Final project for ZTM course


1. Clone this repo
2. Run `npm install`
3. Run `npm start`

*visist https://zerotomastery.io/ for more*
